<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="misc" tilewidth="96" tileheight="96" tilecount="14" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image source="../../rooms/room 1/wood.png" width="32" height="32"/>
 </tile>
 <tile id="2">
  <image source="../../rooms/room 1/plant.png" width="32" height="64"/>
 </tile>
 <tile id="3">
  <image source="../../rooms/room 1/plant2.png" width="32" height="64"/>
 </tile>
 <tile id="4">
  <image source="../../rooms/room 1/table.png" width="64" height="32"/>
 </tile>
 <tile id="6">
  <image source="../../rooms/room 1/chair.png" width="32" height="32"/>
 </tile>
 <tile id="7">
  <image source="../../rooms/room 1/chest.png" width="32" height="32"/>
 </tile>
 <tile id="9">
  <image source="../../rooms/room 1/chest2.png" width="32" height="64"/>
 </tile>
 <tile id="10">
  <image source="../../rooms/room 5/leveroff.png" width="32" height="32"/>
 </tile>
 <tile id="11">
  <image source="../../rooms/room 6/topwood.png" width="32" height="32"/>
 </tile>
 <tile id="12">
  <image source="../../rooms/room 6/bottomwood.png" width="32" height="32"/>
 </tile>
 <tile id="13">
  <image source="../../rooms/room 7/painting.png" width="96" height="96"/>
 </tile>
 <tile id="16">
  <image source="../tiles/test.png"/>
 </tile>
 <tile id="17">
  <image source="../tiles/test2.png"/>
 </tile>
 <tile id="18">
  <image source="../tiles/portal.png" width="64" height="96"/>
 </tile>
</tileset>
