<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="doors" tilewidth="32" tileheight="32" tilecount="10" columns="5">
 <image source="../tiles/doors.png" width="160" height="64"/>
</tileset>
